package com.cookandroid.app;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edit1, edit2;
    Button btnAdd, btnSub, btnMul, btnDiv, btnRemain;
    TextView textResult;
    String num1, num2;
    double result;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("초간단 계산기(수정)");

        edit1 = (EditText) findViewById(R.id.Edit1);
        edit2 = (EditText) findViewById(R.id.Edit2);

        btnAdd = (Button) findViewById(R.id.BtnAdd);
        btnSub = (Button) findViewById(R.id.BtnSub);
        btnMul = (Button) findViewById(R.id.BtnMul);
        btnDiv = (Button) findViewById(R.id.BtnDiv);
        btnRemain = (Button) findViewById(R.id.BtnRemain);

        textResult = (TextView) findViewById(R.id.TextResult);
        btnAdd.setOnClickListener((arg0) -> {
            if(checkOperands(edit1, edit2)) {
                applyResult(evalutionFromEditText("+", edit1, edit2));
            } else {
                Toast.makeText(this.getApplicationContext(),"두개의 값을 다 입력하신 후 시도해주세요", Toast.LENGTH_SHORT).show();
            }
        });

        btnSub.setOnClickListener((arg0) -> {
            if(checkOperands(edit1, edit2)) {
                applyResult(evalutionFromEditText("-", edit1, edit2));
            } else {
                Toast.makeText(this.getApplicationContext(),"두개의 값을 다 입력하신 후 시도해주세요", Toast.LENGTH_SHORT).show();
            }
        });

        btnMul.setOnClickListener((arg0) -> {
            if(checkOperands(edit1, edit2)) {
                applyResult(evalutionFromEditText("*", edit1, edit2));
            } else {
                Toast.makeText(this.getApplicationContext(),"두개의 값을 다 입력하신 후 시도해주세요", Toast.LENGTH_SHORT).show();
            }
        });

        btnDiv.setOnClickListener((arg0) -> {
            if(checkOperands(edit1, edit2)) {
                if(Double.parseDouble(edit2.getText().toString()) != 0) {
                    applyResult(evalutionFromEditText("/", edit1, edit2));
                } else {
                    Toast.makeText(this.getApplicationContext(),"0으로 나누실 수 없습니다", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this.getApplicationContext(),"두개의 값을 다 입력하신 후 시도해주세요", Toast.LENGTH_SHORT).show();
            }
        });

        btnRemain.setOnClickListener((arg0) -> {
            if(checkOperands(edit1, edit2)) {
                applyResult(evalutionFromEditText("%", edit1, edit2));
            } else {
                Toast.makeText(this.getApplicationContext(),"두개의 값을 다 입력하신 후 시도해주세요", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public boolean checkOperands(EditText x, EditText y) {
        return checkOperand(x) && checkOperand(y);
    }

    public boolean checkOperand(EditText x) {
        return x.getText() != null && !x.getText().toString().equals("");
    }

    public void applyResult(double result) {
        textResult.setText("계산 결과 : " + result);
    }

    public double evalutionFromEditText(String operator, EditText x, EditText y) {
        return evalution(operator, x.getText().toString(), y.getText().toString());
    }

    public double evalution(String operator, String x, String y) {
        return evalution(operator, Double.parseDouble(x), Double.parseDouble(y));
    }

    public double evalution(String operator, double x, double y) {
        switch(operator) {
            case "+": return x+y;
            case "-": return x-y;
            case "*": return x*y;
            case "/": return x/y;
            case "%": return x%y;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
